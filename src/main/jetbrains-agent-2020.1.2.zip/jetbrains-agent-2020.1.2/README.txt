 ========================================================================
 =======    Jetbrains Activation Code And License Server Crack    =======
 =======                     https://zhile.io                     =======
 =======              v3.2.1, Build Date: 2020-04-11              =======
 ========================================================================

 *** 如果你下载的jetbrains-agent.jar小于2M，肯定是没有下载完全（可对照sha1sum.txt）。***
 *** 请保留压缩包内的important.txt和jetbrains-agent.jar放在同一个目录，且不要改动内容！***

 *** 传统的vmoptions配置需要技巧，我推荐你还是按照本文档的方式配置！***

 Usage:
 0. Download the zip package and get jetbrains-agent.jar first.
    Download page: https://zhile.io/2018/08/17/jetbrains-license-server-crack.html
 1. Run the IDE and evalutate for free.
    You can reset eval by using: reset_eval script.
 2. Drag the jetbrains-agent.jar into the IDE window (Or install it as an IDE plugin).
    (Actually you can drag jetbrains-agent-latest.zip too)
    Click "Restart" button to restart your IDE.
 3. You will see the JetbrainsAgent Helper dialog.
    Select license type and click install button.
 4. Restart IDE, and all done.
 x. Support "License server" and "Activation code":
    1). Entry license server address: https://fls.jetbrains-agent.com (Or http, if failed see no.2 [below])
    2). Active offline with the activation code file: ACTIVATION_CODE.txt
        License key is in legacy format == Key invalid，check your agent's config again
        If you need a custom license name, visit: https://zhile.io/custom-license.html
    3). Now you can activate jetbrains paid plugin with jetbrains-agent + activation code/license server!
        Jetbrains paid plugins activation code: https://zhile.io/jetbrains-paid-plugins-license.html
        All paid plugins: https://plugins.jetbrains.com/search?isPaid=true

 使用方法:
 0. 先下载压缩包解压后得到jetbrains-agent.jar。
    下载页面：https://zhile.io/2018/08/17/jetbrains-license-server-crack.html
 1. 启动你的IDE，如果上来就需要注册，选择：试用（Evaluate for free）进入IDE。
    如果你的IDE试用已过期可以使用reset_eval文件夹内的脚本重置一下。
 2. 将 jetbrains-agent.jar 拖进IDE窗口（或者当作IDE插件安装），点 "Restart" 按钮重启IDE。
    （事实上你拖 jetbrains-agent-latest.zip 进去IDE窗口也没问题）
 3. 在弹出的JetbrainsAgent Helper对话框中，选择激活方式，点击安装按钮。
 4. 重启IDE，搞定。
 x. 支持两种注册方式：License server 和 Activation code:
    1). 选择License server方式，地址填入：https://fls.jetbrains-agent.com （HTTP也可用，网络不佳用第2种方式）
    2). 选择Activation code方式离线激活，请使用：ACTIVATION_CODE.txt 内的注册码激活
        License key is in legacy format == Key invalid，表示agent配置未生效。
        如果你需要自定义License name，请访问：https://zhile.io/custom-license.html
    3). 现在你可以使用jetbrains-agent + activation code/license server激活jetbrains平台的付费插件了！
        现有Jetbrains付费插件Activation code: https://zhile.io/jetbrains-paid-plugins-license.html
        现在有这些付费插件：https://plugins.jetbrains.com/search?isPaid=true

 本项目在最新2020.1.2上测试通过。
 理论上适用于目前Jetbrains全系列所有新老版本（这句话是瞎说的，如有问题请给我issue或进QQ群：30347511讨论）。
 IDE升级会从旧版本导入以上设置，导入配置后可能提示未注册（因为刚导入的vmoptions未生效），直接重启IDE即可，无需其他操作。


 本项目只做学习研究之用，不得用于商业用途！
 若资金允许，请点击 [https://www.jetbrains.com/idea/buy/] 购买正版，谢谢合作！
 学生凭学生证可免费申请 [https://sales.jetbrains.com/hc/zh-cn/articles/207154369-学生授权申请方式] 正版授权！
 创业公司可5折购买 [https://www.jetbrains.com/shop/eform/startup] 正版授权！
